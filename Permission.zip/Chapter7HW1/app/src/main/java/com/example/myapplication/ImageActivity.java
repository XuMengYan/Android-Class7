package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class ImageActivity extends AppCompatActivity {


    List<View> views = new ArrayList<>();
    LayoutInflater inflater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inflater = getLayoutInflater();
        setContentView(R.layout.activity_image);

        ViewPager viewPager = findViewById(R.id.view_pager);
        addImage(R.drawable.image1);
        addImage(R.drawable.image2);
        addImage(R.drawable.image3);
        addImage("/sdcard/fileimage.jpg");
        addImage(R.drawable.image4);
        addImage("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563274259657&di=3b5db9c0c6c90446883acd17c2e15e51&imgtype=0&src=http%3A%2F%2Fi0.hdslb.com%2Fbfs%2Fbangumi%2F122cd0a282c0ecb83aaf3a2b0c7efd50a8ffa77a.jpg");
        ImageAdapter adapter = new ImageAdapter();
        adapter.setDatas(views);
        viewPager.setAdapter(adapter);


    }

    private void addImage(int resId) {
        ImageView imageView = (ImageView) inflater.inflate(R.layout.layout_image, null);
        Glide.with(this)
                .load(resId)
                .into(imageView);
        views.add(imageView);
    }

    private void addImage(String path) {
        ImageView imageView = (ImageView) inflater.inflate(R.layout.layout_image, null);
        Glide.with(this)
                .load(path)
                //.apply(new RequestOptions().circleCrop().diskCacheStrategy(DiskCacheStrategy.ALL))
                .into(imageView);
        views.add(imageView);
    }
}
